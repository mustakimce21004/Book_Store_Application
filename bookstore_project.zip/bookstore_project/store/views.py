from django.shortcuts import render
from dataclasses import dataclass
from typing import List

# ---- Book Catalog ----
catalog = {
    "9781234567890": 25.99,
    "9789876543210": 30.00,
    "9781111111111": 45.50,
    "9782222222222": 18.75
}

@dataclass
class OrderItem:
    isbn: str
    quantity: int

def is_valid_isbn(isbn: str) -> bool:
    return len(isbn) == 13 and isbn.isdigit()

def apply_discount(price: float, quantity: int) -> float:
    total = price * quantity
    return total * 0.9 if quantity > 3 else total

def order_view(request):
    if request.method == 'POST':
        isbns = request.POST.getlist('isbn')
        quantities = request.POST.getlist('quantity')
        receipt = []
        total = 0.0
        errors = []

        for isbn, qty_str in zip(isbns, quantities):
            if not isbn:
                continue
            if not is_valid_isbn(isbn):
                errors.append(f"Invalid ISBN: {isbn}")
                continue
            try:
                quantity = int(qty_str)
            except ValueError:
                errors.append(f"Invalid quantity for ISBN {isbn}")
                continue
            if isbn not in catalog:
                errors.append(f"ISBN not found in catalog: {isbn}")
                continue

            price = catalog[isbn]
            line_total = apply_discount(price, quantity)
            receipt.append((isbn, quantity, price, line_total))
            total += line_total

        return render(request, 'receipt.html', {
            'receipt': receipt,
            'total': total,
            'errors': errors
        })

    return render(request, 'order_form.html')
